## Extra tests

These extra tests are intended to be run from a Vagrant VM that has already had its environment set up -- see the section in the README for more details.

